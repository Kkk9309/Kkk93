var player = require('./player');

module.exports = {
  StripchatPlayer: player,
};
